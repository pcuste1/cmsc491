package com.adamjshook.storm.demo.app.model;

import static com.google.common.base.MoreObjects.toStringHelper;

public class TagCountBean {
	private String tag;
	private Long count;

	public TagCountBean() {
	}

	public TagCountBean(String tag, Long count) {
		this.tag = tag;
		this.count = count;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return toStringHelper(this).add("tag", tag).add("count", count).toString();
	}
}
