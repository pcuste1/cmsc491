package com.adamjshook.storm.demo.app.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adamjshook.storm.demo.app.model.DataFetcher;
import com.adamjshook.storm.demo.app.model.TagCountBean;
import com.adamjshook.storm.demo.app.model.TweetBean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

@Controller()
public class MetaDataController {
	private static final Logger LOG = LoggerFactory.getLogger(MetaDataController.class);
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	private DataFetcher fetcher = DataFetcher.getDefault();

	@RequestMapping(value = "/tweets", method = RequestMethod.GET)
	@ResponseBody
	public List<TweetBean> lookup(@RequestParam(value = "word", defaultValue = "") String word) throws Exception {
		LOG.info("Fetching last ten tweets");
		List<TweetBean> tweets = fetcher.fetchLastTenTweets();
		LOG.info("Returning {} tweets", tweets.size());
		return tweets;
	}

	@RequestMapping(value = "/hashtags", method = RequestMethod.GET)
	@ResponseBody
	public List<TagCountBean> hashtags() throws Exception {
		LOG.info("Loading trending hashtags");
		List<TagCountBean> hts = fetcher.fetchTrendingHashtags();
		LOG.info("Returning {} hashtags", hts.size());
		return hts;
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	@ResponseBody
	public List<TagCountBean> users() throws Exception {
		LOG.info("Loading popular users");
		List<TagCountBean> users = fetcher.fetchPopularUsers();
		LOG.info("Returning {} users", users.size());
		return users;
	}
}
