package com.adamjshook.storm.demo.app.model;

import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;

import redis.clients.jedis.JedisPool;

public class RedisDataFetcher extends DataFetcher {

	// Mapper to decode TweetBean objects
	private ObjectMapper mapper = new ObjectMapper();

	// TODO Create new JedisPool
	// This is a thread-safe pool of Jedis objects to retrieve data
	private JedisPool jedis = null;

	private static final String HASHTAG_KEY = "hashtags";
	private static final String POPUSERS_KEY = "popusers";
	private static final String TWEETBEAN_KEY = "tweetbeans";

	@Override
	public List<TweetBean> fetchLastTenTweets() throws Exception {
		// TODO fetch last ten tweets and return them
		return ImmutableList.of();
	}

	@Override
	public List<TagCountBean> fetchTrendingHashtags() throws Exception {
		// TODO fetch top trending hashtags and return them as a pair of
		// (hashtag, count)
		return ImmutableList.of();
	}

	@Override
	public List<TagCountBean> fetchPopularUsers() throws Exception {
		// TODO fetch top trending hashtags and return them as a pair of
		// (screen_name, count)
		return ImmutableList.of();
	}
}
