package com.adamjshook.storm.demo.app.model;

import java.util.List;

public abstract class DataFetcher {
	/**
	 * Gets the default data fetcher
	 * 
	 * @return
	 */
	public static DataFetcher getDefault() {
		return new RedisDataFetcher();
	}

	/**
	 * Gets the last ten tweets, or less if there haven't been some tweets
	 *
	 * @return A list of tweets containing the word, preferably a short one
	 */
	public abstract List<TweetBean> fetchLastTenTweets() throws Exception;

	/**
	 * Gets the top ten trending hashtags
	 *
	 * @return
	 */
	public abstract List<TagCountBean> fetchTrendingHashtags() throws Exception;

	/**
	 * Gets the top ten popular users
	 *
	 * @return
	 */
	public abstract List<TagCountBean> fetchPopularUsers() throws Exception;
}
