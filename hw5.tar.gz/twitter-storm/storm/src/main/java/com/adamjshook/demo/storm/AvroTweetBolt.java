/*
 * Licensed to the Apache Software Foundation (ASF) under one
 *   or more contributor license agreements.  See the NOTICE file
 *   distributed with this work for additional information
 *   regarding copyright ownership.  The ASF licenses this file
 *   to you under the Apache License, Version 2.0 (the
 *   "License"); you may not use this file except in compliance
 *   with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package com.adamjshook.demo.storm;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
//import twitter.Tweets;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import twitter.Tweet;

public class AvroTweetBolt extends BaseRichBolt {
	private static final long serialVersionUID = 1L;
	public static final String HASHTAG_STREAM = "hashtags";
	public static final String POPULAR_USERS_STREAM = "pop_users";
	public static final String TWEETBEAN_STREAM = "tweetbeans";

	// To decode Twitter's createdAt string to a java.util.Date object
	private SimpleDateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy");
	private DatumReader<Tweet> datumReader;
	
	
	protected static final Logger LOG = LoggerFactory.getLogger(AvroTweetBolt.class);
	private OutputCollector collector;

	@SuppressWarnings("rawtypes")
	@Override
	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
		// TODO any initialization steps go here
		//avro datumReader
		Tweet tweet = new Tweet();
		this.datumReader= new SpecificDatumReader<Tweet>(Tweet.class);
	}

	@Override
	public void execute(Tuple input) {
		System.out.println("[3] Inside of execute. Did I run?");
				
		// TODO Get decode your Avro object from the input field. Also get this blasted line to run
		Decoder decoder = DecoderFactory.defaultFactory().binaryDecoder(input.getBinaryByField("avro"), null);
		
		// TODO Emit each hashtag to the HASHTAG_STREAM, one hashtag per tuple
		List<Object> list = new ArrayList<Object>();
		collector.emit(HASHTAG_STREAM, list);
		
		// TODO Emit a tuple of (screen name, num followers) to the
		// POPULAR_USERS_STREAM
		collector.emit(POPULAR_USERS_STREAM, list);
		
		// TODO Emit a tuple of (TweetBean, created_at time (as long integer))
		// to TWEETBEAN_STREAM
		collector.emit(TWEETBEAN_STREAM, list);
		
		// TODO ack the input tuple via collector
		collector.ack(input);
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO declare the output schemas of ALL THREE streams
		Fields hfield = new Fields("hashtag");
		declarer.declareStream(HASHTAG_STREAM, hfield);
		Fields ufield = new Fields("users");
		declarer.declareStream(POPULAR_USERS_STREAM, ufield);
		Fields bfield = new Fields("tweetbean");
		declarer.declareStream(TWEETBEAN_STREAM, bfield);
	}
}