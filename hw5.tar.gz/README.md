# HOMEWORK 5: My Grades Last Hope (Not really)

Currently implemented:
  * Building topology in Driver.java
  * KafkaSpout.java in its entirety
  * AvroTweetBolt.java
    * Create Avro datumReader
    * Deserializes tuple
    * Create Streams for Redis function
  * RedisSetTweetBeanBolt.java
    * Sets variables
    * Opens Jedis
    * aks tuple
    * Closes Jedis
  * RedisSetUsersBolt.java
    * Sets variables 
    * Opens Jedis
    * aks tuple
    * Closes Jedis
  * RedisIncrHashtagBolt.java
    * Sets variables 
    * Opens Jedis
    * aks tuple
    * Closes Jedis

Currently not implemented:
   * Distinguishing different items to send to redis
   * Using redis functions

Software Requirements:
* [HDFS](http://hadoop.apache.org)
* [Avro](http://avro.apache.org) tools jar file, Avro module (pip install avro)
* [Kafka](http://kafka.apache.org)
* [Storm](http://storm.apache.org)
* [Redis](http://redis.apache.org)

###Part 0 - Preliminary steps
  * Make sure that Kafka is running
  * Make sure that redis is running
    * http://m2eclipse.sonatype.org/sites/m2e/
    * redis-cli
    * # Should bring up a shell like this one
    * 127.0.0.1:6379 >
  * Make sure that Storm is running by running these 3 commands in separate windows.
    * storm nimbus
    * storm supervisor
    * storm ui

###Part 1 - Eclipse
  * Set your working directory as twitter-storm
  * If you do not already have the maven plug in for eclipse:
    * add http://m2eclipse.sonatype.org/sites/m2e/ to your available software install links
  * Import the project into eclipse. 

###Part 2 - Quick code edits
  * If you want to use a avro schema other than the provided Tweets.java
    * Compile your schema into a .java file
    * Add to the twitter package 
    * Change the value of TWEET_STREAM to your file name 
    * Edit any necessary avro calls in AvroTweetBolt.java

###Part 3 - running the code
  * In eclipse, click on the storm folder to expand it in the Project Explorer
  * Navigate to com.adamjshook.demo.storm package
  * Open the Driver.java file
  * Press: ctrl - alt - x j 

###Part 4 - grading the code
  * Give it a lot of love and care 
  * Bigger numbers are appreciated
  * Buy yourself a game on steam with my credit card
    * 1234-1234-1234-1234 
    * Special code: 420
  * Have I mentioned how lovely you look today? 
  * Reasons to give me a good grade: plz
