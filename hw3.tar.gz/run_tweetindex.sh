#!/bin/sh
export JAVA_HOME=/usr/java/default

cd /home/pcuste1/pig

LOG_DIR5=/home/pcuste1/pig/analytics/error_logs/tophashtags

LOG_FILE5=$LOG_DIR5/`date +%Y%m%d_%H%M%S`.log

mkdir -p $LOG_DIR5

PIG_SCRIPT5=tophashtags.pig

OUTPUT5=/analytics/tophashtags/`date -u -d '1 hour ago' +%Y/%m/%d/%H`
INPUT=/user/pcuste1/in/trump_dump/`date -u -d '1 hour ago' +%Y/%m/%d/%H`

RUN_CMD5="/opt/pig/bin/pig -p input=$INPUT -p output=$OUTPUT5 -f $PIG_SCRIPT5"

echo $RUN_CMD5
$RUN_CMD5 &> $LOG_FILE5

rm pig_* 