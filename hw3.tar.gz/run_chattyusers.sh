#!/bin/sh
export JAVA_HOME=/usr/java/default

cd /home/pcuste1/pig

LOG_DIR3=/home/pcuste1/pig/analytics/error_logs/chattyusers

LOG_FILE3=$LOG_DIR3/`date +%Y%m%d_%H%M%S`.log

mkdir -p $LOG_DIR3

PIG_SCRIPT3=chattyusers.pig

OUTPUT3=/analytics/chattyusers/`date -u -d '1 hour ago' +%Y/%m/%d/%H`
INPUT=/user/pcuste1/in/trump_dump/`date -u -d '1 hour ago' +%Y/%m/%d/%H`

RUN_CMD3="/opt/pig/bin/pig -p input=$INPUT -p output=$OUTPUT3 -f $PIG_SCRIPT3"

echo $RUN_CMD3
$RUN_CMD3 &> $LOG_FILE3

rm pig_* 