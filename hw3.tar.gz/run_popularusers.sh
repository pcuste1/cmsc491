#!/bin/sh
export JAVA_HOME=/usr/java/default

cd /home/pcuste1/pig

LOG_DIR2=/home/pcuste1/pig/analytics/error_logs/popularusers

LOG_FILE2=$LOG_DIR2/`date +%Y%m%d_%H%M%S`.log

mkdir -p $LOG_DIR2

PIG_SCRIPT2=popularusers.pig

OUTPUT2=/analytics/popularusers/`date -u -d '1 hour ago' +%Y/%m/%d/%H`
INPUT=/user/pcuste1/in/trump_dump/`date -u -d '1 hour ago' +%Y/%m/%d/%H`

RUN_CMD2="/opt/pig/bin/pig -p input=$INPUT -p output=$OUTPUT2 -f $PIG_SCRIPT2"

echo $RUN_CMD2
$RUN_CMD2 &> $LOG_FILE2
rm pig_* 