#!/bin/sh
export JAVA_HOME=/usr/java/default

cd /home/pcuste1/pig

LOG_DIR1=/home/pcuste1/pig/analytics/error_logs/userinfo
LOG_FILE1=$LOG_DIR1/`date +%Y%m%d_%H%M%S`.log

mkdir -p $LOG_DIR1
PIG_SCRIPT1=userinfo.pig

OUTPUT1=/analytics/userinfo/`date -u -d '1 hour ago' +%Y/%m/%d/%H`
INPUT=/user/pcuste1/in/trump_dump/`date -u -d '1 hour ago' +%Y/%m/%d/%H`

RUN_CMD1="/opt/pig/bin/pig -p input=$INPUT -p output=$OUTPUT1 -f $PIG_SCRIPT1"
echo $RUN_CMD1
$RUN_CMD1 &> $LOG_FILE1

rm pig_* 