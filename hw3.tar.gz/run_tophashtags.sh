#!/bin/sh
export JAVA_HOME=/usr/java/default

cd /home/pcuste1/pig

LOG_DIR4=/home/pcuste1/pig/analytics/error_logs/tweetindex

LOG_FILE4=$LOG_DIR4/`date +%Y%m%d_%H%M%S`.log

mkdir -p $LOG_DIR4

PIG_SCRIPT4=tweetindex.pig

OUTPUT4=/analytics/tweetindex/`date -u -d '1 hour ago' +%Y/%m/%d/%H`
INPUT=/user/pcuste1/in/trump_dump/`date -u -d '1 hour ago' +%Y/%m/%d/%H`

RUN_CMD4="/opt/pig/bin/pig -p input=$INPUT -p output=$OUTPUT4 -f $PIG_SCRIPT4"

echo $RUN_CMD4
$RUN_CMD4 &> $LOG_FILE4

rm pig_* 