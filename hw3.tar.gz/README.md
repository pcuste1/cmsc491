### Pig Analytics

#### Overview

There are seven artifacts all together: sample data files, analytics, and a sample cronjob.
* __tweet.avsc__
  * Sample Avro file containing Tweet data
* __userinfo.pig__
  * Analytic that loads tweet data and outputs the user ID, and related fields from the tweets meta data.
* __chattyusers.pig__
  * Analytic that determines the top 100 most-chatty users from the data set. 
* __tweetindex.pig__
  * Analytic which generates a mapping of user ID to individual words from the tweet data.
* __popularusers.pig__
  * Analytic which determines the 100 most popular users by followers count.
* __tophashtags.pig__
  * Analytic that groups usernames by hashtags then determines the top 100 hashtags used. 
* __crontab.txt__
  * A sample crontab for scheduling the run script
* __run_*.sh__
  * Run script to execute a Pig analytic via cron

#### Execution Modes

Pig has two execution modes, `mapred` (the default) and `local`.  `mapred` uses your Hadoop cluster to execute the job in parallel, while `local` uses your local file system for reading data and writing output.  You should use `local` mode during development, pulling down sample files as needed.  You can specify the mode using the `-x` flag when running `pig`.

To run a script, use the `-f` flag and pass `pig` the filename to execute.  You can use multiple `-p` flags to specify the values of parameters in your script.

```bash
# Starts a grunt shell using the default mapred mode
# Identical to "pig -x mapred"
$ pig

# Starts a grunt shell using the local mode
$ pig -x local

# Executes a file in local mode with the given input and output properties
$ pig -x local -p input=localfile.txt -p output=outputdir -f myanalytic.pig
```
#### Installation

This will walk through creating a cronjob for scheduling the _Top Champions_ analytic using the provided templates under the `cronjob` directory.

First, create an `analytics` directory in your home directory to install all analytics (we'll just be installing one here -- the other two are an exercise for the reader).  Then, create a `topchampions` directory and copy `topchampions.pig` and `cronjob/run.sh.template` to this directory.

```bash
$ mkdir -p ~/analytics/tophashtags
$ cp pig/tophashtags.pig ~/analytics/tophashtags/
$ cp pig/run_tophashtags.sh ~/analytics/tophashtags/run_tophashtags.sh
```

Now, edit `~/analytics/tophashtags/run_tophashtags.sh` to fit your needs -- update folders to your own Linux username, change input/output paths as necessary, change path to the `pig` executable, etc.

Now, using `cronjob/crontab.template` as a guide, edit your crontab via `crontab -e` (which will open a text editor) and set the trigger time and the script to be executed.  After you edit your crontab, quit the text editor and you'll see that the crontab has been saved.  Use `crontab -l` to list your current crontab.

```bash
$ crontab -e
crontab: installing new crontab
$ crontab -l
5 * * * * /home/analytics/tophashtags/run_tophashtags.sh
```