#!/usr/bin/python
#from __future__ import absolute_import, print_function
import avro.schema, json, logging, sys, time, tweepy
from avro.io import AvroTypeException, BinaryEncoder, DatumWriter
from kafka import KafkaProducer
from StringIO import StringIO
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream

brokers = sys.argv[1]
topic = sys.argv[2]

# Please no steal my consumer keys and what not. Have mercy oh great grader god!
consumer_key = "qHtm2YyiQYzmxW5iEhMhaeDNI"
consumer_secret = "yLPUf03WVRPel0isWJ839SZW02G87Osce2jMfiGSEvBDoEW3fL"
access_token = "4878662620-GzpRusVAkAgsGSGcSvZbOr5p5pDVOtZXV0XRro6"
access_token_secret = "pXU6YExaeMe7NE3a3gshrNWYUAFmMLxiZyP3TdNZN1NAW"

schema = avro.schema.parse(open("twitter_avro.avsc").read())
writer = DatumWriter(writers_schema=schema)
counter = 0
n = 1

def __init_logging():
    """Initialized the logging module for the RPYC Server"""
    root = logging.getLogger()
    root.setLevel(logging.getLevelName("INFO"))
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    root.addHandler(ch)
    

class StdOutListener(StreamListener):
    
    _topic = None
    _producer = None

    def on_data(self, dataStr):
        data = json.loads(str(dataStr))
        
        # Catch for deleted tweets and "limit" tweets.
        try:
            data["limit"]
            return True
        except:
            time.sleep(0)
        try:
            data["delete"]
            return True
        except:
            time.sleep(0)
        try:
            # The next few thousand lines create an avro object using the data.
            avro_object = dict()
            
            avro_object["created_at"] = data["created_at"]
            avro_object["text"] = data["text"]
            avro_object["source"] = data["source"]
            avro_object["retweet_count"] = data["retweet_count"]
            avro_object["favorite_count"] = data["favorite_count"]
            
            avro_object["entities"] = dict()
            if data["entities"]["hashtags"] != []:
                pHashtags = dict()
                pHashtags["hastags"] = data["entities"]["hashtags"][0]["text"]
                avro_object["entities"]["hashtags"] = pHashtags
            else:
                avro_object["entities"]["hashtags"] = dict()

            if data["entities"]["urls"] != []:
                pUrls = dict()
                pUrls["url"] = data["entities"]["urls"][0]["url"]
                pUrls["display_url"] = data["entities"]["urls"][0]["display_url"]
                pUrls["expanded_url"] = data["entities"]["urls"][0]["expanded_url"]
                avro_object["entities"]["urls"] = pUrls
            else:
                avro_object["entities"]["urls"] = dict()

            if data["entities"]["user_mentions"] != []:		
                pUser_mentions = dict()
                pUser_mentions["id"] = data["entities"]["user_mentions"][0]["id"]
                pUser_mentions["id_string"] = data["entities"]["user_mentions"][0]["id_str"]
                pUser_mentions["screen_name"] = data["entities"]["user_mentions"][0]["screen_name"]
                avro_object["entities"]["user_mentions"] = pUser_mentions
            else:
                avro_object["entities"]["user_mentions"] = dict()

            avro_object["coordinates"] = dict()
            if data[u"coordinates"] != None:
                avro_object["coordinates"]["latitude"] = data[u"coordinates"]["coordinates"][0]
                avro_object["coordinates"]["longitude"] = data[u"coordinates"]["coordinates"][1]
            else:
                avro_object["coordinates"]["latitude"] = ("  ")
                avro_object["coordinates"]["longitude"] = ("  ")

            avro_object["user"] = dict()
            avro_object["user"]["id"] = data["user"]["id"]
            avro_object["user"]["screen_name"] = data["user"]["screen_name"]
            avro_object["user"]["location"] = data["user"]["location"]
            avro_object["user"]["description"] = data["user"]["description"]
            avro_object["user"]["followers_count"] = data["user"]["followers_count"]
            avro_object["user"]["statuses_count"] = data["user"]["statuses_count"]
            avro_object["user"]["geo_enabled"] = data["user"]["geo_enabled"]
            avro_object["user"]["lang"] = data["user"]["lang"]

            # we then create an avro object in the form of a binary stream
            stream = StringIO()
            encoder = BinaryEncoder(stream)
            
            writer.write(avro_object, encoder)
       
            # we send it off to kafka. Weeeeeeeeeeeeeeeeeeeeeeeeeee
            self._producer.send(self._topic, stream.getvalue())
            self._producer.flush()
            
            return True
    
        except AvroTypeException as e:
            print e

        except:
            # For timeouts. Scaling so that it will hopefully not kick me off. I hope!
            global n
            n += 1
            time.sleep(2**n)
    
            print str(sys.exc_info()[0])

    def on_error(self, status_code):
        print("got and error with status code: " + str(status_code))
                
    def on_timeout(self):
        print("timeout...")
        return True

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print "usage: python producer.py <server.port> <brokers> <topic>"
        print "    brokers - comma-delimited list of host:port pairs for Kafka brokers"
        print "    topic - Kafka topic to post messages to, must exist"
        sys.exit(1)

    __init_logging()

    brokers = sys.argv[1]
    topic = sys.argv[2]
    
    listener = StdOutListener()
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)	
    
    listener._producer = KafkaProducer(bootstrap_servers=brokers)
    listener._topic = topic
    
    stream = Stream(auth, listener)
    
    stream.filter(track=['trump'])
    
