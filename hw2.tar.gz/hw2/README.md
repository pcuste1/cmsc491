# The great 2016 Trump Dump

Currently implemented:
  * Pull Twitter data as JSON
  * Avro schema containing select fields from Twitter data model
  * Kafka Producer
    * Converts Twitter Data to Avro schema
    * Serialized Avro object to a binary representation
    * Publishes message to Kafka topic
  * Kafka Consumer
    * Receives messages from Kafka topic
    * Batches messages into a temporary file
    * Moves file to HDFS
  

Software Requirements
---------------------
The following softare products and other items are required.  Acquisition, Installation, configuration, and setup of these tools are outside the scope of this project.

* [HDFS](http://hadoop.apache.org)
* [Avro](http://avro.apache.org) tools jar file, Avro module (pip install avro)
* [Kafka](http://kafka.apache.org)
* [kafka-python](https://github.com/dpkp/kafka-python) __must be cloned and installed from Github.__ pip version is out of date
* [tweepy](https://github.com/tweepy/tweepy) pip install tweepy
* HDFS Client Machine (`hdfs` command line tool is available and properly configured)

##Python

###Part 1 - Avro Schema

Inspect `twitter_avro.avsc`.  This Avro schema contains select fields from the Twitter tweet API

###Part 2 - Twitter Ingestion

#### Overview
There are three files for ingesting data in Avro.

* __twitter_producer.py__
  * Receives tweepy calls containing `tweet` JSON data
  * Pulls selected fields from `tweet` JSON data and creates an Avro objects
  * Encodes Avro object as binary data
  * Publishes binary Avro data to configured Kafka stream
* __twitter_consumer.py__
  * Receives messages from configured Kafka topic
  * Decodes binary Avro data to Avro object
  * Logs Avro object
  * Writes Avro object to local temporary file
  * After _n_ number of messages have been written or after _n_ seconds, roll over file
  * Move file to configured HDFS directory
  
#### Execution


First, create the Kafka topic for posting messages, using your ZooKeeper and Kafka configuration

```
$ kafka-topics.sh --zookeeper localhost:2181 --create --topic trump_dump --partitions 1 --replication-factor 1
Created topic "trump_dump".
```

Then, start the Kafka producer:

```
$ python twitter_producer.py 
usage: python producer.py <server.port> <brokers> <topic>
    brokers - comma-delimited list of host:port pairs for Kafka brokers
    topic - Kafka topic to post messages to, must exist
$ python twitter_producer.py localhost:9092 trump_dump
2016-02-25 15:44:57,205 - kafka.client - INFO - Broker version identifed as 0.9
```

In a separate terminal, start the Kafka consumer:

```
$ python twitter_consumer.py
usage: python twitter_consumer.py <brokers> <topic> <output> <messages.per.file>
    brokers - comma-delimited list of host:port pairs for Kafka brokers
    topic - Kafka topic to post messages to, must exist
    output - Absolute HDFS directory to write files to, e.g. /in/lol
    messages.per.file - Number of messages to write to a single file before rolling over
    time.per.file - Max time allocated to a writting single file before rolling over
$ python twitter_consumer.py localhost:9092 trump_dump /in/trump_dump 10 10
```
Both the producer and consumer will log messages as they are produced/consumed.  After 10 messages are consumed, they will be written to a file in HDFS under the directory you specified.

```
$ hdfs dfs -ls -R /in/
drwxr-xr-x   - pcuste1 supergroup          0 2016-02-25 15:59 /in/trump_dump
drwxr-xr-x   - pcuste1 supergroup          0 2016-02-25 15:59 /in/trump_dump/2016
drwxr-xr-x   - pcuste1 supergroup          0 2016-02-25 15:59 /in/trump_dump/2016/02
drwxr-xr-x   - pcuste1 supergroup          0 2016-02-25 16:00 /in/trump_dump/2016/02/25
drwxr-xr-x   - pcuste1 supergroup          0 2016-02-25 16:01 /in/trump_dump/2016/02/25/21
-rw-r--r--   1 pcuste1 supergroup       1329 2016-02-25 16:00 /in/trump_dump/2016/02/25/21/tweet-1456452008.avro
-rw-r--r--   1 pcuste1 supergroup       1329 2016-02-25 16:00 /in/trump_dump/2016/02/25/21/tweet-1456452025.avro
-rw-r--r--   1 pcuste1 supergroup       1329 2016-02-25 16:00 /in/trump_dump/2016/02/25/21/tweet-1456452042.avro
-rw-r--r--   1 pcuste1 supergroup       1329 2016-02-25 16:01 /in/trump_dump/2016/02/25/21/tweet-1456452058.avro
-rw-r--r--   1 pcuste1 supergroup       1329 2016-02-25 16:01 /in/trump_dump/2016/02/25/21/tweet-1456452075.avro
-rw-r--r--   1 pcuste1 supergroup       1329 2016-02-25 16:01 /in/trump_dump/2016/02/25/21/tweet-1456452092.avro
```

You can download one of these files and view the contents using the Avro tools jar file.

```
$ hdfs dfs -get /in/lol/2016/02/25/21/data-1456452042.avro
$ java -jar /opt/avro/avro-tools-1.8.0.jar tojson data-1456452042.avro

Output: 

{"twitter.avro.Tweet":{"created_at":{"string":"Wed Mar 02 00:47:47 +0000 2016"},"id":null,"text":{"string":"RT @HahnAmerica: Trump is anything but self-funded. He's put less than $300,000 of his own money into the campaign. He's raised $7 million.…"},"user":{"id":{"long":860690676},"screen_name":{"string":"BeaBeataz21"},"location":null,"description":{"string":"Conservative working wife and mom who doesn't need the government to tell her what to do and who to be."},"statuses_count":{"int":629},"geo_enabled":{"boolean":false},"lang":{"string":"en"},"followers_count":{"int":144}},"coordinates":{"latitude":{"string":"  "},"longitude":{"string":"  "}},"retweet_count":{"int":0},"favorite_count":{"int":0},"entities":{"hashtags":{"text":null},"urls":{"url":null,"display_url":null,"expanded_url":null},"user_mentions":{"id":{"long":1963571004},"id_string":{"string":"1963571004"},"screen_name":{"string":"HahnAmerica"}}}}}
{"twitter.avro.Tweet":{"created_at":{"string":"Wed Mar 02 00:47:47 +0000 2016"},"id":null,"text":{"string":"RT @SOMEXlCAN: What Hearing Trump's Speech Feels Like As A Mexican-American https://t.co/gjLIJGESIf"},"user":{"id":{"long":1244710758},"screen_name":{"string":"niallbaex"},"location":null,"description":{"string":"somebody loves you more than you think. Shawn and Nash follows✨"},"statuses_count":{"int":8213},"geo_enabled":{"boolean":false},"lang":{"string":"en"},"followers_count":{"int":7636}},"coordinates":{"latitude":{"string":"  "},"longitude":{"string":"  "}},"retweet_count":{"int":0},"favorite_count":{"int":0},"entities":{"hashtags":{"text":null},"urls":{"url":{"string":"https://t.co/gjLIJGESIf"},"display_url":{"string":"amp.twimg.com/v/0b03575f-ded…"},"expanded_url":{"string":"https://amp.twimg.com/v/0b03575f-ded2-4315-a70e-edebb1d9c424"}},"user_mentions":{"id":{"long":818941136},"id_string":{"string":"818941136"},"screen_name":{"string":"SOMEXlCAN"}}}}}
...
```